# tsubasale

A Pen created on CodePen.

Original URL: [https://codepen.io/editor/b83147813967/pen/019f1774-fb58-7c14-8d4d-62b2b0e43556](https://codepen.io/editor/b83147813967/pen/019f1774-fb58-7c14-8d4d-62b2b0e43556).

